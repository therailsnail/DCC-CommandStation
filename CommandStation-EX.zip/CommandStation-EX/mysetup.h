//ACK Settings for Hornby TTS. These may need tweaking, but are usually good to go
SETUP("<D ACK MIN 2000>");
SETUP("<D ACK MAX 8750>");
SETUP("<D ACK LIMIT 20>");
//
//WiFi Specific setup follows:-
//The CommandStation (CS) is setup (here) as an AP (Access Point) and Station (STA connects to an AP - Usually a WiFi Router) - 
//The AP broadcasts an SSID of DCCpp-AP with a WPA-2_PSK encrypted password of 1234567890 on WiFi Channel 5
//So, your device (PC, Laptop, Tablet etc) should be able to connect to SSID DCCpp-AP, out-of-the-box, with a password of 1234567890 without any changes. 
//
//The CS may be configured to also connect to an AP (Router maybe) by modifying the //SETUP("+CWJAP=\"ssid\",\"secret\""); line below. Remove the double slash at the start
//of the line and change ssid to be the SSID of the AP (Router) and secret to be the SSID password. Then re-compile in Arduino IDE and upload via USB to your CS
//
SETUP("+CWMODE=3");                             //Specific WiFi settings for your setup - CWMODE=3 means setup ESP8266 to be an Access Point (AP) and also a Station (STA)
SETUP("+CWHOSTNAME=\"DCCpp-STA\"");             //STA Name (as seen by router) - Note the use of back slash delimiter(\) before the speech marks when they are used within a command.
//SETUP("+CWJAP=\"ssid\",\"secret\"");          //Connect to Router as STA Name with SSID ssid PASSWORD secret. Remove // (comment delimiter) if connecting to a router
SETUP("+CWSAP=\"DCCpp-AP\",\"1234567890\",5,3"); //also set CS to be an AP with SSID DCCpp-AP and PASSWORD 1234567890 on Channel 5 and WPA2_PSK encryption method
SETUP("+CWSAP?");                               //and query it
SETUP("+CIFSR");                                //Get IP Addresses (for AP and STA). (Can be seen if monitoring the serial connection within the Arduino Serial Monitor (or similar))
//
//The following 's' command will cause the CS to send its status. This may be useful when connecting to JMRI as this will allow the JMRI software to quickly know the
//status of track power rather than report unknown. Other DCC commands may be appended maybe to turn off all track power <0>.. See commented example below
//
SETUP("<s>");                                   //Send DCC++ EX CommandStation Status <s> (this will return track power - JMRI (if used) waits on this to know Track power status)
//SETUP("<0>");                                 //turn off track power at CS startup (remove comment delimiters (//), recompile in Arduino IDE and upload to enable this)

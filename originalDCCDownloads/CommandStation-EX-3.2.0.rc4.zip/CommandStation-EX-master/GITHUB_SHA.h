#define GITHUB_SHA "88fa5ad"
